"""Console script entry point."""

import bpclient


def BPClient():

	bpclient.Args()
	bpclient.ExecCommand()


