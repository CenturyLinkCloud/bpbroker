"""Console script entry point."""

import bpmailer


def BPMailer():

	bpmailer.Args()
	bpmailer.ExecCommand()
